const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
var ObjectId = require('mongoose').Types.ObjectId;

var { PFEmpData } = require('./models/employee');
const { mongoose } = require('./db.js');
//var employeeController = require('./controllers/employeeController.js');

var app = express();
/* app.use(bodyParser.urlencoded({
    extended: true
 })); */
app.use(bodyParser.json());
//app.use(cors({ origin: 'http://localhost:4200' }));

app.listen(4000, () => console.log('Server started at port : 4000'));



app.get('/api/getPFVendorEmpDetails', function(req,res){
    console.log("inside vendor");
    console.log("request param:"+ req.query.establishmentId)
    let vendor = [];
    if(req.headers.from == "tatasteel"){
    PFEmpData.find((err, docs) => {
        console.log("list",docs);
        for(let i in docs){
            if(docs[i].establishmentId == req.query.establishmentId){
                vendor.push(docs[i]);
            }
        }
        console.log(vendor);
        res.send(vendor);
    })
}else{
    res.send("Invalid Request");
}
});

app.get('/api/getPFVendorEmpMonthDetails', function(req,res){
    console.log("inside vendor");
    console.log("request param:"+ req.query.establishmentId)
    if(req.headers.from == "tatasteel"){
    let vendor = [];
    
    PFEmpData.find((err, docs) => {
        for(let i in docs){
            if(docs[i].establishmentId == req.query.establishmentId && docs[i].wageMonth == req.query.wageMonth){
                vendor.push(docs[i]);
            }
        }
        console.log(vendor);
        res.send(vendor);
    })
}else{
    res.send("Invalid Request");
}
}); 

app.post('/api/addVendorEmpDetails', function(req,res){
    var emp = new PFEmpData({
        establishmentId: req.body.establishmentId,
        establishmentName: req.body.establishmentName,
        wageMonth: req.body.wageMonth,
        contributionRate: req.body.contributionRate,
        totalMembers: req.body.totalMembers,
        dateOfdisbursement: req.body.dateOfdisbursement,
        totalAmount: req.body.totalAmount,
        memberDetails: req.body.memberDetails
    })
    emp.save((err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Employee Save :' + JSON.stringify(err, undefined, 2)); }
    })
});


/* app.use('/employees', employeeController);
app.use('/getByVendor', function(req,res,next){
    req.vendorId = {
        vendorId : 
    }
}, employeeController);
//app.use('/vendor', employeeController); */


