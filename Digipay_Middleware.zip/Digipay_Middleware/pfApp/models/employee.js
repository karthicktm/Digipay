const mongoose = require('mongoose');

var PFEmpData = mongoose.model('vendorDB', {
    establishmentId: { type: String },
    establishmentName: { type: String },
    wageMonth: { type: String },
    contributionRate: { type: String },
    totalMembers: { type: Number },
    dateOfdisbursement: { type: Date },
    totalAmount: { type: String },
    memberDetails: { type: Array }
});

module.exports = { PFEmpData };

