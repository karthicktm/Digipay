const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const cors = require('cors');
var ObjectId = require('mongoose').Types.ObjectId;
const GridFsStorage = require('multer-gridfs-storage');
//const Grid = require('gridfs-stream');
const axios = require('axios');
var fs = require("fs"), PDFParser = require("pdf2json");
var util = require('util');
//const mongoURI = 'mongodb://localhost:27017/VendorEmpPayDet';
//const conn = mongoose.createConnection(mongoURI);
let gfs;

//var { PFEmpData } = require('./models/employee');
//const { mongoose } = require('./db.js');
//var employeeController = require('./controllers/employeeController.js');

var app = express();
/* app.use(bodyParser.urlencoded({
    extended: true
 })); */
app.use(bodyParser.json());
//app.use(cors({ origin: 'http://localhost:4200' }));

app.listen(5000, () => console.log('Server started at port : 5000'));

var diskStorage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "./uploads");
    },
    filename: function (req, file, callback) {
        callback(null, file.fieldname + "_"+ file.originalname);
    }
});

var diskUpload = multer({ storage: diskStorage }).array("docUploader", 1);

app.get("/api/vendorUpload", function (req, res) {
    res.sendFile(__dirname + "/index.html");
});

app.post("/api/salaryUpload", async (req, res) => {
    var salaryFile ;
    var salaryStr;
    
    
    diskUpload(req, res, function (err) {
        if (err) {
            return res.end("Something went wrong!");
        }
        console.log("OriginalName::::",req.files[0].originalname);
        salaryFile = req.files[0].originalname;
        //console.log("Request Month:"+month);
       console.log("SalaryFile:",salaryFile);
        //upload.single('file');
        //return res.end("File uploaded sucessfully!.");
    
   // console.log("Name:::::",diskUpload.name);
   let pdfParser = new PDFParser(this,1);
   pdfParser.on("pdfParser_dataError", errData => console.error(errData.parserError) );
   pdfParser.on("pdfParser_dataReady", pdfData => {
   //console.log("parser",pdfParser.getRawTextContent());
   var data = pdfParser.getRawTextContent().split("\r\n");
   //console.log(data);
   
   var salary = {
       //emp : {'empId':'','empName':'','empGross':'','empUAN':'','empPFDed':'','empIPNo':'','empESIDed':''}
       emp : []
   };
   salary.vendorName = data[0];
   salary.vendorId = data[1];
   console.log(salary.vendorName+"ID:"+salary.vendorId);
   if(data[2].match("Month")){
    salary.month = (data[2].substring(data[2].indexOf(" ")+1,data[2].indexOf("Year")-1)).trim();
    salary.year = data[2].substring(data[2].length -5, data[2].length);
    console.log("month:"+ salary.month+"--year:"+ salary.year);
    }
    console.log("salary emp"+ salary.emp);
    var myRegEx  = /[^a-z\d]/i;
   for(var i=6; i<8; i++){
       if((data[i].trim.length> 0) || (!data[i].match("Total"))){
         var empDet = data[i].split(" ");
         salary.emp.push({"empId":empDet[0],"empName":empDet[1] +" "+ empDet[2],"empGross":empDet[3],"empUAN":empDet[4],"empPFDed":empDet[5],"empIPNo":empDet[6],"empESIDed":empDet[7]});
       }
   }
        //fs.writeFile("./pdf2json/test/F1040EZ.fields.json", JSON.stringify(pdfParser.getAllFieldsTypes()));
        //console.log("salaryDetails:"+JSON.stringify(salary));
        salaryStr = JSON.stringify(salary);
        console.log("StringObject:", salaryStr);
    });
    //console.log("./temp/docUploaderr_"+salaryFile);
    pdfParser.loadPDF("./uploads/docUploader_"+salaryFile);
  //  pdfParser.loadPDF("./temp/imgUploader_PFChallan.pdf");
    res.end("success");
})
});

app.use('/api/getComplianceDetails', async function(req, res) {  
    var url = 'http://localhost:4000/api/getPFVendorEmpMonthDetails?establishmentId='+req.query.establishmentId+'&wageMonth='+req.query.wageMonth;
    var url2 = 'http://localhost:3000/api/getVendorEmpMonthList?vendorId='+req.query.establishmentId+'&month='+req.query.wageMonth;
    //res.setHeader('content-type', 'application/json');
    //res.setHeader('From','tatasteel');
    var responseOne =  await CallPFSystem(url);
    var responseTwo = await CallTSSystem(url2);
    var responseThree = await CallSalaryFileSystem(req.query.establishmentId,req.query.wageMonth);
    var finalResponse  = responseOne + responseTwo;
    res.send(finalResponse);
  });
  function CallSalaryFileSystem(establishmentId,wageMonth){
    return new Promise(async function (resolve, reject){
        let pdfParser = new PDFParser(this,1);
        pdfParser.on("pdfParser_dataError", errData => console.error(errData.parserError));
        var data = pdfParser.getRawTextContent().split("\r\n");
    })
  }


  function CallPFSystem(url1) {
    return new Promise(async function (resolve, reject) {
        try {
            console.log(url1);
            var url = url1;
            var updateResult;
               await axios.get(url, {
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'From': 'tatasteel'                        
                        },
                    }).then(function (response) {
                        console.log("Response:"+ util.inspect(response.data.toString()));
                        updateResult = JSON.stringify(util.inspect(response.data));
                        console.log(response.data[0].memberDetails[0].UAN);
                    })
                    .catch(function (error) {
                        console.log(error);
                    });                
            resolve(updateResult);
        } catch (err) {
            console.log(err)
        } finally {}
    }).catch((err) => {
        console.log(err)
    });
}

function CallTSSystem(url2) {
    return new Promise(async function (resolve, reject) {
        try {
            console.log(url2);
            var url = url2;
            var updateResult;
               await axios.get(url, {
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                           // 'From': 'tatasteel'                        
                        },
                    }).then(function (response) {
                        console.log("Response:"+ util.inspect(response.data.toString()));
                        updateResult = JSON.stringify(util.inspect(response.data));
                        //console.log(response.data[0].memberDetails[0].UAN);
                    })
                    .catch(function (error) {
                        console.log(error);
                    });                
            resolve(updateResult);
        } catch (err) {
            console.log(err)
        } finally {}
    }).catch((err) => {
        console.log(err)
    });
}






