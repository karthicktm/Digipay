const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
var ObjectId = require('mongoose').Types.ObjectId;

var { Employee } = require('./models/employee');
const { mongoose } = require('./db.js');
var employeeController = require('./controllers/employeeController.js');

var app = express();
/* app.use(bodyParser.urlencoded({
    extended: true
 })); */
app.use(bodyParser.json());
//app.use(cors({ origin: 'http://localhost:4200' }));

app.listen(3000, () => console.log('Server started at port : 3000'));

app.get('/api/getAllEmployees',function(req,res){
    Employee.find((err, docs) => {
        if (!err) { res.send(docs); }
        else { console.log('Error in retriving employees details :' + JSON.stringify(err, undefined, 2)); }
    })
});

app.get('/api/getVendorEmpList', function(req,res){
    console.log("inside vendor");
    
    console.log("request param:"+ req.query.vendorId)
    let vendor = [];
    Employee.find((err, docs) => {
        for(let i in docs){
            if(docs[i].empVendorId == req.query.vendorId){
                vendor.push(docs[i]);
            }
        }
        console.log(vendor);
        res.send(vendor);
    })
});

app.get('/api/getVendorEmpMonthList', function(req,res){
    console.log("inside vendor");
    console.log("request param:"+ req.query.vendorId)
    let vendor = [];
    Employee.find((err, docs) => {
        for(let i in docs){
            if(docs[i].empVendorId == req.query.vendorId && docs[i].month == req.query.month){
                vendor.push(docs[i]);
            }
        }
        console.log(vendor);
        res.send(vendor);
    })
});

app.post('/api/addEmployee', function(req,res){
    var emp = new Employee({
        empName: req.body.empName,
        empVendorId: req.body.empVendorId,
        empVendorName: req.body.empVendorName,
        uan: req.body.uan,
        ipnumber: req.body.ipnumber,
        noOfDaysWorked: req.body.noOfDaysWorked,
        month: req.body.month,
        year: req.body.year
    })
    emp.save((err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Employee Save :' + JSON.stringify(err, undefined, 2)); }
    })
});


/* app.use('/employees', employeeController);
app.use('/getByVendor', function(req,res,next){
    req.vendorId = {
        vendorId : 
    }
}, employeeController);
//app.use('/vendor', employeeController); */


