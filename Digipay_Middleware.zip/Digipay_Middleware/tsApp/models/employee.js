const mongoose = require('mongoose');

var Employee = mongoose.model('Employee', {
    vendorId: { type: String },
    vendorName: { type: String },
    month: { type: String },
    year:  { type: String },
    vendorEmpDetails: { type: Array }
});

module.exports = { Employee };

